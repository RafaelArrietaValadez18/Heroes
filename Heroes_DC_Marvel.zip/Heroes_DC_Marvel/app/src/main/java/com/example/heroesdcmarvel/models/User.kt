package com.example.heroesdcmarvel.models

data class User(val email : String, val password : String){
    companion object{
        val staticUsers = listOf(User(email="jose@hotmail.com",password="1234"),
            User(email="jose1@hotmail.com",password="1234"),
            User(email="jose2@hotmail.com",password="1234"),
            User(email="jose3@hotmail.com",password="1234"),
            User(email="jose4@hotmail.com",password="1234")
            )
    }
}