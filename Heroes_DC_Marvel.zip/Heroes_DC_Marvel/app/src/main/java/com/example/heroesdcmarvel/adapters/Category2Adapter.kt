package com.example.heroesdcmarvel.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.heroesdcmarvel.R
import com.example.heroesdcmarvel.models.category2
import java.util.Locale.Category

class Category2Adapter (val categories: List<category2>)
    : RecyclerView.Adapter<Category2ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Category2ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.category_item,parent,false)
        return Category2ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return categories.count()
    }

    override fun onBindViewHolder(holder: Category2ViewHolder, position: Int) {
        TODO("Not yet implemented")
    }
}
class Category2ViewHolder(view: View) : RecyclerView.ViewHolder(view)