package com.example.heroesdcmarvel.models

class category2(val id: String, val name: String, val image: String) {

}